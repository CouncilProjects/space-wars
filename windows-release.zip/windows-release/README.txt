Space Wars

How to install:
All you have to do is run the setup.exe and follow the prompts

Space Wars

How to Play

Welcome to Space Wars! Here’s a quick guide on how to play the game:

1. Move with Arrow Keys:
   - Use the Arrow keyes or the WASD keys to move your spaceship around the screen.

2. Shoot:
   - Press the Spacebar to fire bullets at enemies.

3. Pause the Game:
   - Press Escape (Esc) to pause the game.

4. Collect Points:
   - Destroy enemies to collect points. Points are left behind by destroyed enemies and can be collected for your score.

5. Damage Mechanics:
   - Only bullets can damage the player. Collisions with other ships will not cause damage.

Enjoy my game!

-Space Wars a game made with SDL 
